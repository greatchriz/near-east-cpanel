

<!doctype html>
<html lang="zxx">


<!-- Mirrored from bnker.netlify.app/ltr/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Sep 2022 20:52:17 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title> Bnker. - Banking and Loan HTML Templates </title>
    <!-- /Required meta tags -->

    <!-- Favicon -->
    <link rel="shortcut icon" href="/images/favicon.png" type="image/x-icon">
    <!-- /Favicon -->

    <!-- All CSS -->

    <!-- Vendor Css -->
    <link rel="stylesheet" href="/css/vendors.css">
    <!-- /Vendor Css -->

    <!-- Plugin Css -->
    <link rel="stylesheet" href="/css/plugins.css">
    <!-- Plugin Css -->

    <!-- Icons Css -->
    <link rel="stylesheet" href="/css/icons.css">
    <!-- /Icons Css -->

    <!-- Style Css -->
    <link rel="stylesheet" href="/css/style.css">
    <!-- /Style Css -->

    <!-- /All CSS -->

</head>

<body>
    <!-- PreLoader -->
    <div id="preloader">
        <div id="status">
            <div class="spinner"></div>
        </div>
    </div>
    <!--Preloader-->



    <?php echo e($slot); ?>


    



    <!-- JS -->

    <!-- Vendor Js -->
    <script src="/js/vendors.js"></script>
    <!-- /Vendor js -->

    <!-- Plugins Js -->
    <script src="/js/plugins.js"></script>
    <!-- /Plugins Js -->

    <!-- Main JS -->
    <script src="/js/main.js"></script>
    <!-- /Main JS -->

    <!-- /JS -->

</body>


<!-- Mirrored from bnker.netlify.app/ltr/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 05 Sep 2022 20:56:43 GMT -->
</html>



<?php /**PATH /home/reconsxo/neareast-bank.com/resources/views/layouts/app.blade.php ENDPATH**/ ?>