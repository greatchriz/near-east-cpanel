<button <?php echo e($attributes->merge(['type' => 'submit'])); ?>>
    <?php echo e($slot); ?>

</button>
<?php /**PATH C:\Users\HP\Downloads\money\resources\views/components/button.blade.php ENDPATH**/ ?>