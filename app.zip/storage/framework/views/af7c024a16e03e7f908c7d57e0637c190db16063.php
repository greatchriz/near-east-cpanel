<!-- Choose Us -->
<div class="why-choose-us-area pb-100">
    <!-- Container -->
    <div class="container">
        <!-- row -->
        <div class="row align-items-center">
            <!-- col -->
            <div class="col-lg-6">
                <div class="why-choose-us-img">
                    <img src="/images/bg/choose-us.png" alt="Image">
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-lg-6">
                <div class="why-choose-us-content mb-removed">
                    <!-- row -->
                    <div class="row justify-content-center text-center">
                        <!-- col -->
                        <div class="col-lg-8 col-md-12 mb-50">
                            <div class="section-title">
                                <h2 class="title">Why choose us</h2>
                                <div class="title-bdr">
                                    <div class="left-bdr"></div>
                                    <div class="right-bdr"></div>
                                </div>
                                <p>Client likes seeing our work skills</p>
                            </div>
                        </div>
                        <!-- /col -->
                    </div>
                    <!-- /row -->
                    <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut
                        labore et dolore magna aliqua. Quis ipsum suspendisse ultrices gravida. Risus commodo
                        viverra maecenas accumsan lacus vel facilisis.</p>
                    <ul>
                        <li>
                            <i class="ri-check-line"></i>
                            <h3>Transparent</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua.</p>
                        </li>
                        <li>
                            <i class="ri-check-line"></i>
                            <h3>Proactive</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua.</p>
                        </li>
                        <li>
                            <i class="ri-check-line"></i>
                            <h3>Affordable</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua.</p>
                        </li>
                        <li>
                            <i class="ri-check-line"></i>
                            <h3>Flexible</h3>
                            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor
                                incididunt ut labore et dolore magna aliqua.</p>
                        </li>
                    </ul>
                </div>
            </div>
            <!-- /col -->
        </div>
        <!-- /row -->
    </div>
    <!-- /Container -->
</div>
<!-- /Choose Us -->
<?php /**PATH C:\Users\HP\Downloads\money\resources\views/components/choose-us.blade.php ENDPATH**/ ?>