<div class="col-md-6 col-lg-3">
    <div class="iq-card iq-card-block iq-card-stretch iq-card-height">
        <div class="iq-card-body">
            <div class="user-details-block">
                <div class="user-profile text-center">
                    <img src="/dash/images/user/11.png" alt="profile-img" class="avatar-100 img-fluid rounded">
                </div>
                <div class="text-center mt-3">
                    <h4><b>Barry Tech</b></h4>
                    <p class="mb-0">Manager</p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3">
    <div class="iq-card iq-card-block iq-card-stretch iq-card-height"
        style="background: transparent; box-shadow: none;">
        <div class="iq-card-body p-0">
            <a href="#"><img src="/dash/images/booking/03.png" class="img-fluid w-100 rounded shadow"
                    alt=""></a>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3">
    <div class="iq-card iq-card-block iq-card-stretch iq-card-height"
        style="background: transparent; box-shadow: none;">
        <div class="iq-card-body p-0">
            <a href="#"><img src="/dash/images/booking/04.png" class="img-fluid w-100 rounded shadow"
                    alt=""></a>
        </div>
    </div>
</div>
<div class="col-md-6 col-lg-3">
    <div class="iq-card iq-card-block iq-card-stretch iq-card-height"
        style="background: transparent; box-shadow: none;">
        <div class="iq-card-body p-0">
            <a href="#"><img src="/dash/images/booking/05.png" class="img-fluid w-100 rounded shadow"
                    alt=""></a>
        </div>
    </div>
</div>
