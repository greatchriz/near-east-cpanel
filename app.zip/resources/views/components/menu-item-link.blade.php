<a {{ $attributes->merge(['class' => 'iq-waves-effect']) }}>

        {{ $slot }}</a>
