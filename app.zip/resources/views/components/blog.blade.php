<!-- Blog -->
<div class="blog-area pt-120 pb-100">
    <!-- Container-->
    <div class="container">
        <!-- row -->
        <div class="row">
            <!-- col -->
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="blog-wrapper mb-30">
                    <div class="blog-img">
                        <a href="blog-single.html"><img src="/images/blog/blog1.jpg" alt=""></a>
                    </div>
                    <div class="blog-text">
                        <h4><a href="blog-single.html">Lorem ipsum dolor sit amet.
                            </a>
                        </h4>
                        <a href="blog-single.html">Read More <i class="ri-arrow-right-line"></i></a>
                        <div class="blog-meta">
                            <span> <i class="las la-calendar"></i> 05 Feb 2022</span>
                            <span> <i class="lar la-heart"></i>Comments (03)</span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="blog-wrapper mb-30">
                    <div class="blog-img">
                        <a href="blog-single.html"><img src="/images/blog/blog2.jpg" alt=""></a>
                    </div>
                    <div class="blog-text">
                        <h4><a href="blog-single.html">Lorem ipsum dolor sit amet.</a>
                        </h4>
                        <a href="blog-single.html">Read More <i class="ri-arrow-right-line"></i></a>
                        <div class="blog-meta">
                            <span> <i class="las la-calendar"></i> 05 Feb 2022</span>
                            <span> <i class="lar la-heart"></i>Comments (03)</span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-4 col-lg-4 col-md-6">
                <div class="blog-wrapper mb-30">
                    <div class="blog-img">
                        <a href="blog-single.html"><img src="/images/blog/blog3.jpg" alt=""></a>
                    </div>
                    <div class="blog-text">
                        <h4><a href="blog-single.html">Lorem ipsum dolor sit amet.</a>
                        </h4>
                        <a href="blog-single.html">Read More <i class="ri-arrow-right-line"></i></a>
                        <div class="blog-meta">
                            <span> <i class="las la-calendar"></i> 05 Feb 2022</span>
                            <span> <i class="lar la-heart"></i>Comments (03)</span>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /col -->
        </div>
        <!-- /row -->
    </div>
    <!-- /Container-->
</div>
<!-- /Blog -->
