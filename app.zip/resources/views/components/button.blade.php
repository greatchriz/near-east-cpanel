<button {{ $attributes->merge(['type' => 'submit']) }}>
    {{ $slot }}
</button>
