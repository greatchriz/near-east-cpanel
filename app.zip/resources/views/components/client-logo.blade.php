<!-- Client Logo -->
<div class="client-logo-area pb-100">
    <!-- Container -->
    <div class="container">
        <!-- row -->
        <div class="row">
            <!-- col -->
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6 text-center">
                <div class="client-logo">
                    <div class="client-logo-img"> <img src="/images/client-logo/logo-envato.png" alt=""
                            class="img-fluid"></div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6 text-center">
                <div class="client-logo">
                    <div class="client-logo-img"> <img src="/images/client-logo/logo-converkit.png" alt=""
                            class="img-fluid"></div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6 text-center">
                <div class="client-logo">
                    <div class="client-logo-img"> <img src="/images/client-logo/logo-buzzumo.png" alt=""
                            class="img-fluid"></div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6 text-center">
                <div class="client-logo">
                    <div class="client-logo-img"> <img src="/images/client-logo/logo-buffer.png" alt=""
                            class="img-fluid">
                    </div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6 text-center">
                <div class="client-logo">
                    <div class="client-logo-img"> <img src="/images/client-logo/logo-frame.png" alt=""
                            class="img-fluid"></div>
                </div>
            </div>
            <!-- /col -->
            <!-- col -->
            <div class="col-xl-2 col-lg-3 col-md-3 col-sm-6 col-6 text-center">
                <div class="client-logo">
                    <div class="client-logo-img"> <img src="/images/client-logo/logo-clearbit.png" alt=""
                            class="img-fluid">
                    </div>
                </div>
            </div>
            <!-- /col -->
        </div>
        <!-- row -->
    </div>
    <!-- /Container -->
</div>
<!-- /Client Logo -->
