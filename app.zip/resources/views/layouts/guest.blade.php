<x-app-layout>
    {{ $slot }}
</x-app-layout>
