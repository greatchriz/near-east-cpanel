<x-app-layout>
    <x-home-header />

    <x-hero />
    <x-featured />
    <x-about />
    <x-services />
    <x-testimonial />
    <x-choose-us />
    <x-client-logo />
    <x-cta />
    <x-home-footer />


</x-app-layout>
