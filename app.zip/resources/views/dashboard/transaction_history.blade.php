<x-authenticated>
    <x-transactions />

</x-authenticated>
