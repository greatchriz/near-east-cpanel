<x-authenticated>
    <x-user-profile />

</x-authenticated>
