<x-authenticated>
    <x-form />

</x-authenticated>
