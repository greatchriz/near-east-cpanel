<x-authenticated>

    <x-atm-cards />

    <x-chart-history />

    <x-simple-cards />

    <x-transactions />

</x-authenticated>
